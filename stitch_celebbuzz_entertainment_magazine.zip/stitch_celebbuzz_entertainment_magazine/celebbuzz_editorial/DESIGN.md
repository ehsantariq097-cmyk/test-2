---
name: CelebBuzz Editorial
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#e6bdb8'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#ac8884'
  outline-variant: '#5c403c'
  surface-tint: '#ffb4ab'
  primary: '#ffb4ab'
  on-primary: '#690005'
  primary-container: '#dc2626'
  on-primary-container: '#fff6f5'
  inverse-primary: '#bf0715'
  secondary: '#c9c6c5'
  on-secondary: '#313030'
  secondary-container: '#4a4949'
  on-secondary-container: '#bab8b7'
  tertiary: '#c8c6c5'
  on-tertiary: '#303030'
  tertiary-container: '#737272'
  on-tertiary-container: '#fbf8f7'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb4ab'
  on-primary-fixed: '#410002'
  on-primary-fixed-variant: '#93000b'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c9c6c5'
  on-secondary-fixed: '#1c1b1b'
  on-secondary-fixed-variant: '#474646'
  tertiary-fixed: '#e5e2e1'
  tertiary-fixed-dim: '#c8c6c5'
  on-tertiary-fixed: '#1b1b1c'
  on-tertiary-fixed-variant: '#474746'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  headline-xxl:
    fontFamily: Playfair Display
    fontSize: 56px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-xxl-mobile:
    fontFamily: Playfair Display
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.15'
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-xl-mobile:
    fontFamily: Playfair Display
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: '0'
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.25'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: '1.5'
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.08em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1.3'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 3rem
---

## Brand & Style

This design system establishes a high-end, cinematic entertainment aesthetic characterized by bold editorial confidence and sleek, immersive storytelling. The brand personality is authoritative yet provocative, sophisticated, and unapologetically glamorous. 

The visual language draws from high-fashion print layouts merged with modern streaming entertainment interfaces. It evokes the feeling of exclusive front-row access, red-carpet urgency, and intimate celebrity journalism.

### Design Style
A hybrid of **Minimalism** and **High-Contrast Boldness**, heavily anchored in a persistent dark mode environment. The foundation relies on absolute blacks and layered dark grays, punctuated by high-impact crimson red accents and crisp, luminous whites for headlines. Visual drama is achieved through massive editorial typography, generous whitespace around imagery, and restrained, razor-sharp UI framing.

## Colors

The color system is optimized for high-end digital publishing, utilizing a dramatic monochromatic foundation that lets high-resolution photography and cinematic accents command full attention.

- **Primary:** Crimson Red (`#DC2626`) serves as the visceral accent for breaking news badges, interactive states, and live updates, commanding immediate attention.
- **Secondary:** Void Black (`#0A0A0A`) acts as the absolute canvas for the dark-first reading experience.
- **Tertiary:** Obsidian Surface (`#1F1F1F`) defines structured containers, cards, and navigation tiers against the deeper background.
- **Neutral:** Pure White (`#FAFAFA`) provides pristine contrast for primary editorial reading, ensuring maximum legibility.

## Typography

Typography bridges timeless magazine heritage with modern digital utility. High-contrast serif headlines in Playfair Display command the viewport with cinematic gravitas, while Inter handles body and micro-copy with clinical precision.

Ensure all uppercase category labels (`label-md` and `label-sm`) utilize generous tracking (`letter-spacing`) to mimic high-fashion print mastheads and section headers.

## Layout & Spacing

A **fluid 12-column grid** provides rigorous structure for asymmetric editorial layouts, picture galleries, and long-form celebrity features. 

- **Gutters & Margins:** Maintain consistent 24px (`1.5rem`) gutters on desktop, scaling down to 16px on mobile. Outer margins breathe at 32px (`2rem`) to prevent dense visual clutter at the viewport edges.
- **Breakpoints:** Mobile (< 768px) stacks all hero modules linearly; Tablet (768px – 1024px) introduces two-column asymmetric grids; Desktop (> 1024px) unlocks full multi-column immersive editorial spreads with sticky sidebar tickers.

## Elevation & Depth

Depth is established primarily through tonal stratification of dark surfaces rather than heavy drop shadows. 

- **Tonal Layers:** The base background (`#0A0A0A`) sits at the lowest layer. Surface cards (`#1F1F1F`) float above via subtle contrast separation.
- **Ambient Shadows:** Where floating elements (dropdowns, modals, sticky navbars) require elevation, use ultra-diffused, low-opacity black shadows (`0 12px 32px rgba(0, 0, 0, 0.6)`) to lend weight without destroying the flat, premium aesthetic.
- **Ghost Borders:** Employ hairline borders (`1px solid rgba(255, 255, 255, 0.08)`) to cleanly separate grid cells and content modules.

## Shapes

The shape language favors crisp geometry with restrained softening. A low roundedness profile (`0.25rem` base, `0.5rem` for large containers) preserves a sharp, high-end editorial sensibility. Pill shapes (`9999px`) are strictly reserved for status tags, category labels, and primary interactive call-to-actions to create intentional contrast against sharp-cornered photographic containers.

## Components

### Buttons
- **Primary:** Solid crimson red (`#DC2626`) fill with pure white label text, using a subtle hover brightness shift. Zero border-radius for sharp, assertive styling or pill-shaped for action triggers.
- **Secondary:** Transparent fill with a 1px white outline, transitioning to a white fill on dark text upon hover.

### Chips & Tags
- Pill-shaped micro-elements featuring an obsidian surface background (`#1F1F1F`) with an uppercase `label-sm` font. Used for tagging celebrity names, trending topics, or content formats (e.g., "EXCLUSIVE", "GALLERY").

### Lists & Feeds
- Clean divider lines using low-opacity borders. Story feed items utilize thumbnail-to-text ratios that prioritize photography, featuring bold serif headlines that scale fluidly on hover.

### Checkboxes & Radio Buttons
- Minimalist geometric indicators. Unchecked states feature a crisp 1px gray border on an obsidian background; checked states snap immediately to solid crimson red with a clean white inner checkmark.

### Input Fields
- Underlined or ghost-bordered text fields with dark gray surface fills. Focus states transition the bottom border or full outline to crimson red without shifting surrounding layout bounds.

### Cards
- **Editorial Cards:** Edge-to-edge imagery with gradient overlays fading from transparent to void black at the base, anchoring white serif headlines directly onto the visual canvas.
- **Standard News Cards:** Solid obsidian surface (`#1F1F1F`) with a hairline border, internal padding, and distinct metadata rows separating author, timestamp, and category.

### Specialized Components
- **Breaking News Ticker:** A high-velocity horizontal marquee anchored to the top viewport edge, utilizing a solid crimson background with bold tracking typography.
- **Gallery Lightbox:** Immersive full-screen dark overlay designed for high-res paparazzi and red-carpet photography, featuring minimalist chrome controls.